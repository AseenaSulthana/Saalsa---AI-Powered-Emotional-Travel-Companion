import type { Config } from "tailwindcss"

export default {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        chart: {
          "1": "hsl(var(--chart-1))",
          "2": "hsl(var(--chart-2))",
          "3": "hsl(var(--chart-3))",
          "4": "hsl(var(--chart-4))",
          "5": "hsl(var(--chart-5))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        serif: ["Playfair Display", "serif"],
        sans: ["Inter", "sans-serif"],
      },
      animation: {
        "fade-in": "fadeIn 0.5s ease-in-out",
        "slide-up": "slideUp 0.3s ease-out",
        "pulse-soft": "pulseSoft 2s ease-in-out infinite",
        "particle-float": "particleFloat 6s ease-in-out infinite",
        "glow-pulse": "glowPulse 2s ease-in-out infinite",
        "organic-pulse": "organicPulse 4s ease-in-out infinite",
        "blob-float": "blobFloat 8s ease-in-out infinite",
        "spin-slow": "spin 8s linear infinite",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { transform: "translateY(10px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
        pulseSoft: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.7" },
        },
        particleFloat: {
          "0%, 100%": { transform: "translateY(0px) rotate(0deg)" },
          "33%": { transform: "translateY(-10px) rotate(120deg)" },
          "66%": { transform: "translateY(5px) rotate(240deg)" },
        },
        glowPulse: {
          "0%, 100%": {
            boxShadow: "0 0 5px rgba(251, 113, 133, 0.5)",
            transform: "scale(1)",
          },
          "50%": {
            boxShadow: "0 0 20px rgba(251, 113, 133, 0.8)",
            transform: "scale(1.05)",
          },
        },
        organicPulse: {
          "0%, 100%": {
            transform: "scale(1) rotate(0deg)",
            borderRadius: "50%",
          },
          "25%": {
            transform: "scale(1.1) rotate(90deg)",
            borderRadius: "40% 60% 70% 30%",
          },
          "50%": {
            transform: "scale(0.9) rotate(180deg)",
            borderRadius: "60% 40% 30% 70%",
          },
          "75%": {
            transform: "scale(1.05) rotate(270deg)",
            borderRadius: "30% 70% 60% 40%",
          },
        },
        blobFloat: {
          "0%, 100%": {
            transform: "translateY(0px) scale(1)",
            borderRadius: "50%",
          },
          "25%": {
            transform: "translateY(-20px) scale(1.1)",
            borderRadius: "45% 55% 60% 40%",
          },
          "50%": {
            transform: "translateY(-10px) scale(0.95)",
            borderRadius: "60% 40% 45% 55%",
          },
          "75%": {
            transform: "translateY(-15px) scale(1.05)",
            borderRadius: "40% 60% 55% 45%",
          },
        },
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config
