"use client"

import { useEffect, useRef } from "react"

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  size: number
  opacity: number
  color: string
}

interface FloatingIcon {
  x: number
  y: number
  vx: number
  vy: number
  rotation: number
  rotationSpeed: number
  scale: number
  icon: string
  color: string
}

export function AnimatedBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>()
  const particlesRef = useRef<Particle[]>([])
  const iconsRef = useRef<FloatingIcon[]>([])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    const createParticles = () => {
      const particles: Particle[] = []
      const particleCount = Math.min(50, Math.floor((canvas.width * canvas.height) / 15000))

      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          size: Math.random() * 2 + 1,
          opacity: Math.random() * 0.5 + 0.2,
          color: `hsl(${Math.random() * 60 + 320}, 70%, 80%)`, // Rose to orange hues
        })
      }
      return particles
    }

    const createFloatingIcons = () => {
      const icons: FloatingIcon[] = []
      const iconSymbols = ["♡", "✦", "◯", "△", "◊", "✧"]
      const iconCount = Math.min(8, Math.floor(canvas.width / 200))

      for (let i = 0; i < iconCount; i++) {
        icons.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          rotation: Math.random() * Math.PI * 2,
          rotationSpeed: (Math.random() - 0.5) * 0.02,
          scale: Math.random() * 0.5 + 0.5,
          icon: iconSymbols[Math.floor(Math.random() * iconSymbols.length)],
          color: `hsl(${Math.random() * 60 + 320}, 60%, 70%)`,
        })
      }
      return icons
    }

    const drawConnections = (particles: Particle[]) => {
      ctx.strokeStyle = "rgba(251, 113, 133, 0.1)"
      ctx.lineWidth = 1

      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x
          const dy = particles[i].y - particles[j].y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < 150) {
            const opacity = ((150 - distance) / 150) * 0.2
            ctx.globalAlpha = opacity
            ctx.beginPath()
            ctx.moveTo(particles[i].x, particles[i].y)
            ctx.lineTo(particles[j].x, particles[j].y)
            ctx.stroke()
          }
        }
      }
      ctx.globalAlpha = 1
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update and draw particles
      particlesRef.current.forEach((particle) => {
        particle.x += particle.vx
        particle.y += particle.vy

        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1

        ctx.globalAlpha = particle.opacity
        ctx.fillStyle = particle.color
        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fill()
      })

      // Draw connections
      drawConnections(particlesRef.current)

      // Update and draw floating icons
      ctx.font = "20px serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      iconsRef.current.forEach((icon) => {
        icon.x += icon.vx
        icon.y += icon.vy
        icon.rotation += icon.rotationSpeed

        if (icon.x < -50) icon.x = canvas.width + 50
        if (icon.x > canvas.width + 50) icon.x = -50
        if (icon.y < -50) icon.y = canvas.height + 50
        if (icon.y > canvas.height + 50) icon.y = -50

        ctx.save()
        ctx.translate(icon.x, icon.y)
        ctx.rotate(icon.rotation)
        ctx.scale(icon.scale, icon.scale)
        ctx.globalAlpha = 0.3
        ctx.fillStyle = icon.color
        ctx.fillText(icon.icon, 0, 0)
        ctx.restore()
      })

      ctx.globalAlpha = 1
      animationRef.current = requestAnimationFrame(animate)
    }

    resizeCanvas()
    particlesRef.current = createParticles()
    iconsRef.current = createFloatingIcons()
    animate()

    const handleResize = () => {
      resizeCanvas()
      particlesRef.current = createParticles()
      iconsRef.current = createFloatingIcons()
    }

    window.addEventListener("resize", handleResize)

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return (
    <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" style={{ background: "transparent" }} />
  )
}
