"use client"

import { cn } from "@/lib/utils"

interface CharacterAvatarProps {
  archetype: "quiet-rambler" | "wild-soul" | "story-seeker" | "dream-cartographer"
  size?: "sm" | "md" | "lg" | "xl"
  animated?: boolean
  className?: string
}

const avatarSizes = {
  sm: "w-12 h-12",
  md: "w-16 h-16",
  lg: "w-24 h-24",
  xl: "w-32 h-32",
}

const QuietRamblerAvatar = ({ size = "md", animated = false }: { size: string; animated: boolean }) => (
  <svg viewBox="0 0 100 100" className={cn(size, animated && "animate-organic-pulse")}>
    <defs>
      <linearGradient id="quietGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#60A5FA" />
        <stop offset="100%" stopColor="#6366F1" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="url(#quietGradient)" opacity="0.9" />
    <circle cx="50" cy="35" r="15" fill="white" opacity="0.8" />
    <path d="M35 60 Q50 75 65 60" stroke="white" strokeWidth="3" fill="none" opacity="0.8" />
    <circle cx="42" cy="32" r="2" fill="#6366F1" />
    <circle cx="58" cy="32" r="2" fill="#6366F1" />
    <path d="M30 25 Q50 15 70 25" stroke="white" strokeWidth="2" fill="none" opacity="0.6" />
  </svg>
)

const WildSoulAvatar = ({ size = "md", animated = false }: { size: string; animated: boolean }) => (
  <svg viewBox="0 0 100 100" className={cn(size, animated && "animate-bounce")}>
    <defs>
      <linearGradient id="wildGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FB923C" />
        <stop offset="100%" stopColor="#EF4444" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="url(#wildGradient)" opacity="0.9" />
    <circle cx="50" cy="35" r="15" fill="white" opacity="0.8" />
    <path d="M35 65 Q50 80 65 65" stroke="white" strokeWidth="3" fill="none" opacity="0.8" />
    <circle cx="42" cy="32" r="2" fill="#EF4444" />
    <circle cx="58" cy="32" r="2" fill="#EF4444" />
    <path
      d="M25 20 L35 30 L30 35 L40 25 L45 35 L55 25 L60 35 L65 30 L75 20"
      stroke="white"
      strokeWidth="2"
      fill="none"
      opacity="0.7"
    />
  </svg>
)

const StorySeekerAvatar = ({ size = "md", animated = false }: { size: string; animated: boolean }) => (
  <svg viewBox="0 0 100 100" className={cn(size, animated && "animate-glow-pulse")}>
    <defs>
      <linearGradient id="storyGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#A855F7" />
        <stop offset="100%" stopColor="#EC4899" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="url(#storyGradient)" opacity="0.9" />
    <circle cx="50" cy="35" r="15" fill="white" opacity="0.8" />
    <path d="M35 62 Q50 72 65 62" stroke="white" strokeWidth="3" fill="none" opacity="0.8" />
    <circle cx="42" cy="32" r="2" fill="#A855F7" />
    <circle cx="58" cy="32" r="2" fill="#A855F7" />
    <rect x="35" y="15" width="30" height="20" rx="3" fill="white" opacity="0.6" />
    <line x1="40" y1="20" x2="60" y2="20" stroke="#A855F7" strokeWidth="1" />
    <line x1="40" y1="25" x2="55" y2="25" stroke="#A855F7" strokeWidth="1" />
    <line x1="40" y1="30" x2="60" y2="30" stroke="#A855F7" strokeWidth="1" />
  </svg>
)

const DreamCartographerAvatar = ({ size = "md", animated = false }: { size: string; animated: boolean }) => (
  <svg viewBox="0 0 100 100" className={cn(size, animated && "animate-spin-slow")}>
    <defs>
      <linearGradient id="dreamGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#10B981" />
        <stop offset="100%" stopColor="#14B8A6" />
      </linearGradient>
    </defs>
    <circle cx="50" cy="50" r="45" fill="url(#dreamGradient)" opacity="0.9" />
    <circle cx="50" cy="35" r="15" fill="white" opacity="0.8" />
    <path d="M35 62 Q50 72 65 62" stroke="white" strokeWidth="3" fill="none" opacity="0.8" />
    <circle cx="42" cy="32" r="2" fill="#10B981" />
    <circle cx="58" cy="32" r="2" fill="#10B981" />
    <path d="M50 15 L55 25 L50 20 L45 25 Z" fill="white" opacity="0.7" />
    <circle cx="50" cy="50" r="25" stroke="white" strokeWidth="2" fill="none" opacity="0.4" />
    <path d="M50 25 L50 75 M25 50 L75 50" stroke="white" strokeWidth="1" opacity="0.4" />
  </svg>
)

export function CharacterAvatar({ archetype, size = "md", animated = false, className }: CharacterAvatarProps) {
  const sizeClass = avatarSizes[size]

  const renderAvatar = () => {
    switch (archetype) {
      case "quiet-rambler":
        return <QuietRamblerAvatar size={sizeClass} animated={animated} />
      case "wild-soul":
        return <WildSoulAvatar size={sizeClass} animated={animated} />
      case "story-seeker":
        return <StorySeekerAvatar size={sizeClass} animated={animated} />
      case "dream-cartographer":
        return <DreamCartographerAvatar size={sizeClass} animated={animated} />
      default:
        return <QuietRamblerAvatar size={sizeClass} animated={animated} />
    }
  }

  return <div className={cn("flex items-center justify-center", className)}>{renderAvatar()}</div>
}
