"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Send, Heart, Star } from "lucide-react"
import Link from "next/link"

interface Message {
  id: number
  text: string
  sender: "user" | "rozi"
  timestamp: Date
}

const roziResponses = [
  "I sense you're looking for something peaceful today. There's a quiet garden café near the old cathedral that might speak to your soul. 🌸",
  "Your adventurous spirit is calling! How about exploring that hidden alleyway with the vintage bookshop? Stories are waiting for you there. 📚",
  "I remember you mentioned feeling overwhelmed yesterday. Would you like me to suggest some gentle, safe spaces where you can breathe? 🌿",
  "The sunset from the hill overlooking the city is particularly magical today. Perfect for reflection and letting your thoughts wander. 🌅",
  "I've noticed you love collecting stories. There's a local storyteller at the market square every evening - your kind of magic! ✨",
]

const quickSuggestions = [
  { text: "Where can I watch a quiet sunset?", icon: "🌅" },
  { text: "I want to feel safe here", icon: "🛡️" },
  { text: "I'm bored. Give me something cozy", icon: "☕" },
  { text: "Find me a hidden bookstore", icon: "📚" },
  { text: "I need to breathe and reflect", icon: "🌿" },
  { text: "Show me where locals gather", icon: "👥" },
]

export default function RoziPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello, beautiful soul! I'm Raiza, your gentle travel companion. I'm here to help you discover places that match your heart's rhythm. How are you feeling today? 💫",
      sender: "rozi",
      timestamp: new Date(),
    },
  ])
  const [inputText, setInputText] = useState("")

  const sendMessage = (text: string) => {
    if (!text.trim()) return

    const userMessage: Message = {
      id: messages.length + 1,
      text: text,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])

    // Simulate Rozi's response
    setTimeout(() => {
      const roziMessage: Message = {
        id: messages.length + 2,
        text: roziResponses[Math.floor(Math.random() * roziResponses.length)],
        sender: "rozi",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, roziMessage])
    }, 1000)

    setInputText("")
  }

  const handleSuggestionClick = (suggestion: string) => {
    sendMessage(suggestion)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50">
      {/* Header */}
      <div className="bg-white/30 backdrop-blur-sm border-b border-purple-200 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center text-purple-700 hover:text-purple-800 transition-colors">
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </Link>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-serif text-xl text-purple-800">Raiza</h1>
              <p className="text-sm text-purple-600">Your gentle companion</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto p-4 max-w-4xl">
        {/* Chat Messages */}
        <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                  message.sender === "user"
                    ? "bg-purple-500 text-white"
                    : "bg-white/70 backdrop-blur-sm text-purple-800 border border-purple-200"
                }`}
              >
                <p className="text-sm leading-relaxed">{message.text}</p>
                <p className={`text-xs mt-1 ${message.sender === "user" ? "text-purple-100" : "text-purple-500"}`}>
                  {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Suggestions */}
        <Card className="p-6 bg-white/70 backdrop-blur-sm border-purple-200 mb-6">
          <h3 className="font-serif text-lg text-purple-800 mb-4">Ask Raiza about...</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {quickSuggestions.map((suggestion, index) => (
              <Button
                key={index}
                variant="outline"
                className="h-auto p-3 text-left justify-start bg-white/50 hover:bg-white/80 border-purple-200 hover:border-purple-300 transition-all duration-300"
                onClick={() => handleSuggestionClick(suggestion.text)}
              >
                <span className="mr-2">{suggestion.icon}</span>
                <span className="text-sm text-purple-700">{suggestion.text}</span>
              </Button>
            ))}
          </div>
        </Card>

        {/* Message Input */}
        <Card className="p-4 bg-white/70 backdrop-blur-sm border-purple-200">
          <div className="flex space-x-3">
            <Input
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Share what's in your heart..."
              className="flex-1 bg-white/50 border-purple-200 focus:border-purple-400"
              onKeyPress={(e) => e.key === "Enter" && sendMessage(inputText)}
            />
            <Button
              onClick={() => sendMessage(inputText)}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </Card>

        {/* Raiza's Wisdom */}
        <Card className="mt-6 p-6 bg-gradient-to-r from-purple-100 to-pink-100 border-purple-200">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center flex-shrink-0">
              <Star className="w-4 h-4 text-white" />
            </div>
            <div>
              <h4 className="font-serif text-purple-800 mb-2">Raiza's Wisdom</h4>
              <p className="text-sm text-purple-700 italic">
                "Remember, dear traveler, every place has a heartbeat. Sometimes you need to sit quietly and listen to
                find it. I'm here to help you discover those rhythms that match your soul."
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
