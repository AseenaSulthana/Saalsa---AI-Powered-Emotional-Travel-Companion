"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Search, MapPin, Heart, Filter } from "lucide-react"
import Link from "next/link"

const moodFilters = [
  { emoji: "🌙", label: "Peaceful", color: "bg-blue-100 text-blue-800" },
  { emoji: "☀️", label: "Energizing", color: "bg-yellow-100 text-yellow-800" },
  { emoji: "🌿", label: "Healing", color: "bg-green-100 text-green-800" },
  { emoji: "✨", label: "Magical", color: "bg-purple-100 text-purple-800" },
  { emoji: "🔥", label: "Adventurous", color: "bg-red-100 text-red-800" },
  { emoji: "🌊", label: "Calming", color: "bg-cyan-100 text-cyan-800" },
]

const soulSpots = [
  {
    id: 1,
    name: "The Whispering Café",
    location: "Montmartre, Paris",
    description: "Where time slows down and stories are born over steaming cups",
    mood: "🌙",
    hearts: 127,
    image: "/placeholder.svg?height=200&width=300",
    tags: ["quiet", "books", "coffee"],
    story:
      "I found this place when I was lost, both literally and emotionally. The owner, Marie, brought me tea without asking and somehow knew I needed silence more than conversation.",
  },
  {
    id: 2,
    name: "Sunset Point Trail",
    location: "Santorini, Greece",
    description: "Where the sky paints itself in colors that don't have names",
    mood: "✨",
    hearts: 89,
    image: "/placeholder.svg?height=200&width=300",
    tags: ["sunset", "hiking", "views"],
    story:
      "Every step up this trail felt like walking towards something sacred. When I reached the top, I understood why people believe in magic.",
  },
  {
    id: 3,
    name: "The Secret Garden Bookshop",
    location: "Edinburgh, Scotland",
    description: "Hidden between cobblestones, where stories choose their readers",
    mood: "🌿",
    hearts: 156,
    image: "/placeholder.svg?height=200&width=300",
    tags: ["books", "hidden", "cozy"],
    story:
      "I stumbled upon this place during a rainstorm. Three hours later, I emerged with a book that changed my perspective and a friendship with the owner that lasted years.",
  },
  {
    id: 4,
    name: "Moonlit Beach Cove",
    location: "Tulum, Mexico",
    description: "Where waves whisper ancient secrets under starlight",
    mood: "🌊",
    hearts: 203,
    image: "/placeholder.svg?height=200&width=300",
    tags: ["beach", "night", "solitude"],
    story:
      "I came here to cry under the stars after a difficult goodbye. The ocean held my tears and somehow gave me peace in return.",
  },
]

export default function SoulSpotsPage() {
  const [selectedMoods, setSelectedMoods] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [showStory, setShowStory] = useState<number | null>(null)

  const toggleMood = (mood: string) => {
    setSelectedMoods((prev) => (prev.includes(mood) ? prev.filter((m) => m !== mood) : [...prev, mood]))
  }

  const filteredSpots = soulSpots.filter((spot) => {
    const matchesMood = selectedMoods.length === 0 || selectedMoods.includes(spot.mood)
    const matchesSearch =
      searchQuery === "" ||
      spot.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      spot.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      spot.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

    return matchesMood && matchesSearch
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white/30 backdrop-blur-sm border-b border-purple-200 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center text-purple-700 hover:text-purple-800 transition-colors">
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </Link>
          <div className="flex items-center space-x-3">
            <MapPin className="w-6 h-6 text-purple-600" />
            <h1 className="font-serif text-2xl text-purple-800">SoulSpots</h1>
          </div>
        </div>
      </div>

      <div className="container mx-auto p-6 max-w-6xl">
        {/* Search and Filters */}
        <div className="mb-8">
          <Card className="p-6 bg-white/70 backdrop-blur-sm border-purple-200">
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-purple-500" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by feeling, place, or vibe..."
                  className="pl-10 bg-white/50 border-purple-200"
                />
              </div>
              <Button variant="outline" className="bg-white/50 border-purple-200">
                <Filter className="w-4 h-4 mr-2" />
                More Filters
              </Button>
            </div>

            <div>
              <p className="text-sm text-purple-700 mb-3">Filter by mood:</p>
              <div className="flex flex-wrap gap-2">
                {moodFilters.map((mood, index) => (
                  <Button
                    key={index}
                    variant={selectedMoods.includes(mood.emoji) ? "default" : "outline"}
                    size="sm"
                    className={`${selectedMoods.includes(mood.emoji) ? mood.color : "bg-white/50"} border-purple-200`}
                    onClick={() => toggleMood(mood.emoji)}
                  >
                    <span className="mr-1">{mood.emoji}</span>
                    {mood.label}
                  </Button>
                ))}
              </div>
            </div>
          </Card>
        </div>

        {/* Results Header */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="font-serif text-xl text-purple-800">{filteredSpots.length} places that match your soul</h2>
          <div className="text-sm text-purple-600">Rated by feels, not stars ✨</div>
        </div>

        {/* SoulSpots Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {filteredSpots.map((spot) => (
            <Card
              key={spot.id}
              className="overflow-hidden bg-white/70 backdrop-blur-sm border-purple-200 hover:shadow-lg transition-all duration-300"
            >
              <div className="aspect-video bg-gradient-to-br from-purple-200 to-pink-200 relative">
                <img src={spot.image || "/placeholder.svg"} alt={spot.name} className="w-full h-full object-cover" />
                <div className="absolute top-3 right-3">
                  <span className="text-2xl bg-white/80 rounded-full w-10 h-10 flex items-center justify-center">
                    {spot.mood}
                  </span>
                </div>
                <div className="absolute bottom-3 left-3">
                  <div className="flex items-center space-x-2 bg-white/80 rounded-full px-3 py-1">
                    <Heart className="w-4 h-4 text-red-500" />
                    <span className="text-sm font-medium">{spot.hearts}</span>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-serif text-lg text-purple-800 mb-1">{spot.name}</h3>
                    <div className="flex items-center text-sm text-purple-600">
                      <MapPin className="w-3 h-3 mr-1" />
                      {spot.location}
                    </div>
                  </div>
                </div>

                <p className="text-purple-700 mb-4 leading-relaxed">{spot.description}</p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {spot.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className="bg-purple-100 text-purple-700">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex justify-between items-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-purple-600 hover:text-purple-700"
                    onClick={() => setShowStory(showStory === spot.id ? null : spot.id)}
                  >
                    {showStory === spot.id ? "Hide Story" : "Read Story"}
                  </Button>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="bg-white/50 border-purple-200">
                      <Heart className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="outline" className="bg-white/50 border-purple-200">
                      Save
                    </Button>
                  </div>
                </div>

                {showStory === spot.id && (
                  <div className="mt-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
                    <p className="text-sm text-purple-700 italic leading-relaxed">"{spot.story}"</p>
                    <p className="text-xs text-purple-500 mt-2">— Shared by a fellow traveler</p>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>

        {/* Add Your Own Spot */}
        <Card className="mt-8 p-6 bg-gradient-to-r from-purple-100 to-pink-100 border-purple-200">
          <div className="text-center">
            <h3 className="font-serif text-xl text-purple-800 mb-2">Found a place that touched your soul?</h3>
            <p className="text-purple-700 mb-4">
              Share it with fellow travelers and help them find their perfect moments.
            </p>
            <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-full">
              <MapPin className="w-4 h-4 mr-2" />
              Add a SoulSpot
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
