"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CharacterAvatar } from "@/components/character-avatar"
import { AnimatedBackground } from "@/components/animated-background"
import {
  Sun,
  Cloud,
  MapPin,
  BookOpen,
  MessageCircle,
  Calendar,
  Star,
  Compass,
  Coffee,
  Camera,
  Plane,
  Bell,
  Settings,
} from "lucide-react"
import Link from "next/link"

const moodEmojis = [
  { emoji: "✨", label: "Excited", color: "bg-yellow-100/80 text-yellow-800 border-yellow-200" },
  { emoji: "🌊", label: "Calm", color: "bg-blue-100/80 text-blue-800 border-blue-200" },
  { emoji: "🌸", label: "Peaceful", color: "bg-pink-100/80 text-pink-800 border-pink-200" },
  { emoji: "🔥", label: "Adventurous", color: "bg-red-100/80 text-red-800 border-red-200" },
  { emoji: "🌙", label: "Reflective", color: "bg-purple-100/80 text-purple-800 border-purple-200" },
  { emoji: "🌱", label: "Curious", color: "bg-green-100/80 text-green-800 border-green-200" },
]

const dailyQuotes = [
  "The world is a book, and those who do not travel read only one page.",
  "Not all those who wander are lost.",
  "Travel makes one modest. You see what a tiny place you occupy in the world.",
  "Adventure is worthwhile in itself.",
  "To travel is to live.",
]

export default function DashboardPage() {
  const [currentMood, setCurrentMood] = useState<string | null>(null)
  const [archetype, setArchetype] = useState<string | null>(null)
  const [weather, setWeather] = useState<"sunny" | "cloudy">("sunny")
  const [petalsCount, setPetalsCount] = useState(247)

  useEffect(() => {
    const savedArchetype = localStorage.getItem("saalsa-archetype")
    setArchetype(savedArchetype)

    // Simulate weather
    setWeather(Math.random() > 0.5 ? "sunny" : "cloudy")
  }, [])

  const getArchetypeInfo = () => {
    const archetypes = {
      "quiet-rambler": { title: "Quiet Rambler", color: "from-blue-400 to-indigo-500" },
      "wild-soul": { title: "Wild Soul", color: "from-orange-400 to-red-500" },
      "story-seeker": { title: "Story Seeker", color: "from-purple-400 to-pink-500" },
      "dream-cartographer": { title: "Dream Cartographer", color: "from-green-400 to-teal-500" },
    }
    return archetypes[archetype as keyof typeof archetypes] || archetypes["quiet-rambler"]
  }

  const archetypeInfo = getArchetypeInfo()
  const todaysQuote = dailyQuotes[Math.floor(Math.random() * dailyQuotes.length)]

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-rose-50 to-orange-50 relative overflow-hidden">
      <AnimatedBackground />

      {/* Navigation */}
      <nav className="relative z-10 flex justify-between items-center p-6 bg-white/10 backdrop-blur-md border-b border-rose-200/50">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div
              className={`w-8 h-8 bg-gradient-to-br ${archetypeInfo.color} rounded-full flex items-center justify-center animate-glow-pulse`}
            >
              <Compass className="w-4 h-4 text-white" />
            </div>
            <span className="text-2xl font-serif text-rose-800">Saalsa</span>
          </div>

          {archetype && (
            <div className="hidden md:flex items-center space-x-3">
              <CharacterAvatar archetype={archetype as any} size="sm" animated={true} />
              <span className="text-sm text-rose-700">Hello, {archetypeInfo.title}!</span>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-4">
          <Badge className="bg-rose-100/80 text-rose-800 border-rose-200 animate-glow-pulse">
            <Star className="w-3 h-3 mr-1" />
            {petalsCount} petals
          </Badge>
          <Button size="sm" variant="ghost" className="text-rose-600 hover:text-rose-700">
            <Bell className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="ghost" className="text-rose-600 hover:text-rose-700">
            <Settings className="w-4 h-4" />
          </Button>
          <div className="w-8 h-8 bg-gradient-to-br from-rose-300 to-orange-300 rounded-full animate-particle-float"></div>
        </div>
      </nav>

      <div className="relative z-10 container mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              {archetype && <CharacterAvatar archetype={archetype as any} size="lg" animated={true} />}
              <div>
                <h1 className="text-3xl font-serif text-rose-800 mb-2">Welcome back, {archetypeInfo.title}</h1>
                <p className="text-rose-600">How is your soul feeling today?</p>
              </div>
            </div>
            <div className="text-right">
              {weather === "sunny" ? (
                <Sun className="w-12 h-12 text-yellow-500 animate-glow-pulse" />
              ) : (
                <Cloud className="w-12 h-12 text-gray-400 animate-particle-float" />
              )}
            </div>
          </div>

          {/* Mood Check-in */}
          <Card className="p-6 bg-white/20 backdrop-blur-md border-rose-200/50 mb-6 shadow-lg">
            <h3 className="font-serif text-lg text-rose-800 mb-4">Today's Mood Check-in</h3>
            <div className="flex flex-wrap gap-3">
              {moodEmojis.map((mood, index) => (
                <Button
                  key={index}
                  variant={currentMood === mood.label ? "default" : "outline"}
                  className={`${currentMood === mood.label ? mood.color + " shadow-lg" : "bg-white/30 border-rose-200/50"} hover:shadow-md transition-all duration-300 hover:scale-105 backdrop-blur-sm`}
                  onClick={() => setCurrentMood(mood.label)}
                >
                  <span className="mr-2 text-lg">{mood.emoji}</span>
                  {mood.label}
                </Button>
              ))}
            </div>
            {currentMood && (
              <div className="mt-4 p-3 bg-white/30 rounded-lg backdrop-blur-sm animate-fade-in">
                <p className="text-sm text-rose-700">
                  Perfect! I'll tailor today's suggestions to match your {currentMood.toLowerCase()} energy. ✨
                </p>
              </div>
            )}
          </Card>
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Today's Vibe */}
            <Card className="p-6 bg-gradient-to-r from-rose-100/80 to-orange-100/80 border-rose-200/50 backdrop-blur-md shadow-lg">
              <h3 className="font-serif text-xl text-rose-800 mb-3">Today's Vibe</h3>
              <blockquote className="text-lg font-serif italic text-rose-700 mb-4">"{todaysQuote}"</blockquote>
              <div className="flex items-center space-x-4">
                <Button
                  size="sm"
                  className="bg-rose-500 hover:bg-rose-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  <Coffee className="w-4 h-4 mr-2" />
                  Find a cozy café
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="bg-white/50 border-rose-300 rounded-full backdrop-blur-sm hover:bg-white/70"
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Capture this moment
                </Button>
              </div>
            </Card>

            {/* Quick Actions */}
            <div className="grid md:grid-cols-2 gap-4">
              <Link href="/planner">
                <Card className="p-6 bg-white/20 backdrop-blur-md border-rose-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer hover:bg-white/30 group">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-blue-100/80 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <Calendar className="w-5 h-5 text-blue-600" />
                    </div>
                    <h3 className="font-serif text-lg text-rose-800">Plan & Flow</h3>
                  </div>
                  <p className="text-rose-600 text-sm">Create your next soul journey</p>
                </Card>
              </Link>

              <Link href="/journal">
                <Card className="p-6 bg-white/20 backdrop-blur-md border-orange-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer hover:bg-white/30 group">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-orange-100/80 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <BookOpen className="w-5 h-5 text-orange-600" />
                    </div>
                    <h3 className="font-serif text-lg text-orange-800">Saalsa Journal</h3>
                  </div>
                  <p className="text-orange-600 text-sm">Capture your travel emotions</p>
                </Card>
              </Link>

              <Link href="/soulspots">
                <Card className="p-6 bg-white/20 backdrop-blur-md border-purple-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer hover:bg-white/30 group">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-purple-100/80 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <MapPin className="w-5 h-5 text-purple-600" />
                    </div>
                    <h3 className="font-serif text-lg text-purple-800">SoulSpots</h3>
                  </div>
                  <p className="text-purple-600 text-sm">Discover places by feeling</p>
                </Card>
              </Link>

              <Link href="/rozi">
                <Card className="p-6 bg-white/20 backdrop-blur-md border-green-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer hover:bg-white/30 group">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-green-100/80 rounded-full flex items-center justify-center group-hover:animate-bounce">
                      <MessageCircle className="w-5 h-5 text-green-600" />
                    </div>
                    <h3 className="font-serif text-lg text-green-800">Chat with Raiza</h3>
                  </div>
                  <p className="text-green-600 text-sm">Your gentle travel companion</p>
                </Card>
              </Link>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Current Journey */}
            <Card className="p-6 bg-white/20 backdrop-blur-md border-rose-200/50 shadow-lg">
              <h3 className="font-serif text-lg text-rose-800 mb-4">Current Journey</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Plane className="w-5 h-5 text-rose-500 animate-particle-float" />
                  <div>
                    <p className="font-medium text-rose-800">Weekend in Kyoto</p>
                    <p className="text-sm text-rose-600">3 days to go</p>
                  </div>
                </div>
                <div className="w-full bg-rose-200/50 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-rose-500 to-orange-500 h-2 rounded-full animate-pulse"
                    style={{ width: "75%" }}
                  ></div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full bg-white/50 border-rose-300 backdrop-blur-sm hover:bg-white/70"
                >
                  View Details
                </Button>
              </div>
            </Card>

            {/* Saalsa Tip */}
            <Card className="p-6 bg-gradient-to-br from-amber-100/80 to-orange-100/80 border-amber-200/50 backdrop-blur-md shadow-lg">
              <h3 className="font-serif text-lg text-amber-800 mb-3">Daily Saalsa Tip</h3>
              <p className="text-amber-700 text-sm mb-4">
                Pack a book that calms you 🧘‍♀️ Sometimes the best travel companion is a story that grounds your soul.
              </p>
              <Badge className="bg-amber-200/80 text-amber-800 border-amber-300 animate-glow-pulse">Soul Wisdom</Badge>
            </Card>

            {/* Recent Memories */}
            <Card className="p-6 bg-white/20 backdrop-blur-md border-rose-200/50 shadow-lg">
              <h3 className="font-serif text-lg text-rose-800 mb-4">Recent Memories</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3 p-2 rounded-lg bg-white/30 backdrop-blur-sm">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-300 to-blue-500 rounded-full animate-particle-float"></div>
                  <div>
                    <p className="text-sm font-medium text-rose-800">Sunset at Santorini</p>
                    <p className="text-xs text-rose-600">Felt: Peaceful 🌸</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-2 rounded-lg bg-white/30 backdrop-blur-sm">
                  <div
                    className="w-8 h-8 bg-gradient-to-br from-green-300 to-green-500 rounded-full animate-particle-float"
                    style={{ animationDelay: "0.5s" }}
                  ></div>
                  <div>
                    <p className="text-sm font-medium text-rose-800">Hidden café in Paris</p>
                    <p className="text-xs text-rose-600">Felt: Curious 🌱</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
