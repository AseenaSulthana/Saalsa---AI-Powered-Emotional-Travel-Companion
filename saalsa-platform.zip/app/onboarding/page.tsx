"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CharacterAvatar } from "@/components/character-avatar"
import { AnimatedBackground } from "@/components/animated-background"
import { ArrowLeft, ArrowRight, Compass, Sparkles, Heart, BookOpen, Map } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

const questions = [
  {
    id: 1,
    question: "When you think of the perfect travel day, what calls to you?",
    options: [
      { text: "A quiet café where I can watch the world go by", archetype: "quiet-rambler", icon: "☕" },
      { text: "An unexpected adventure that makes my heart race", archetype: "wild-soul", icon: "⚡" },
      { text: "A hidden place with stories waiting to be discovered", archetype: "story-seeker", icon: "📚" },
      { text: "A viewpoint where I can dream and plan my next journey", archetype: "dream-cartographer", icon: "🗺️" },
    ],
  },
  {
    id: 2,
    question: "How do you prefer to navigate a new city?",
    options: [
      { text: "Wander slowly, letting my feet decide the path", archetype: "quiet-rambler", icon: "🚶" },
      { text: "Dive into the chaos and see where it takes me", archetype: "wild-soul", icon: "🌪️" },
      { text: "Follow whispers of local legends and hidden tales", archetype: "story-seeker", icon: "👂" },
      { text: "Study the map first, then create my perfect route", archetype: "dream-cartographer", icon: "📍" },
    ],
  },
  {
    id: 3,
    question: "What do you pack that others might find unusual?",
    options: [
      { text: "A worn journal and my favorite pen", archetype: "quiet-rambler", icon: "📝" },
      { text: "Something that reminds me to say 'yes' to everything", archetype: "wild-soul", icon: "✨" },
      { text: "A book of local folklore or poetry", archetype: "story-seeker", icon: "📖" },
      { text: "Colored pens to mark my maps and plans", archetype: "dream-cartographer", icon: "🖍️" },
    ],
  },
  {
    id: 4,
    question: "When you return from a trip, what do you treasure most?",
    options: [
      { text: "The quiet moments of peace I found", archetype: "quiet-rambler", icon: "🕊️" },
      { text: "The rush of experiences that changed me", archetype: "wild-soul", icon: "💫" },
      { text: "The stories I collected along the way", archetype: "story-seeker", icon: "📚" },
      { text: "The perfect itinerary I can share with others", archetype: "dream-cartographer", icon: "📋" },
    ],
  },
  {
    id: 5,
    question: "What draws you most to a new destination?",
    options: [
      { text: "The promise of solitude and inner reflection", archetype: "quiet-rambler", icon: "🧘" },
      { text: "The thrill of the unknown and untamed", archetype: "wild-soul", icon: "🔥" },
      { text: "The rich history and cultural narratives", archetype: "story-seeker", icon: "🏛️" },
      { text: "The perfect blend of must-sees and hidden gems", archetype: "dream-cartographer", icon: "💎" },
    ],
  },
]

const archetypes = {
  "quiet-rambler": {
    title: "The Quiet Rambler",
    description:
      "You find magic in stillness and beauty in the spaces between moments. Your travels are about inner peace and gentle discovery.",
    traits: ["Mindful", "Peaceful", "Reflective", "Intuitive"],
    color: "from-blue-400 to-indigo-500",
    bgColor: "bg-blue-50",
    icon: Heart,
  },
  "wild-soul": {
    title: "The Wild Soul",
    description:
      "Adventure flows through your veins. You seek experiences that awaken your spirit and stories that make your heart pound.",
    traits: ["Adventurous", "Spontaneous", "Bold", "Free-spirited"],
    color: "from-orange-400 to-red-500",
    bgColor: "bg-orange-50",
    icon: Sparkles,
  },
  "story-seeker": {
    title: "The Story Seeker",
    description:
      "Every place has a tale to tell, and you're here to listen. You collect narratives like others collect souvenirs.",
    traits: ["Curious", "Empathetic", "Cultural", "Wise"],
    color: "from-purple-400 to-pink-500",
    bgColor: "bg-purple-50",
    icon: BookOpen,
  },
  "dream-cartographer": {
    title: "The Dream Cartographer",
    description:
      "You paint your journeys before you live them. Planning is part of the adventure, and every detail matters.",
    traits: ["Organized", "Visionary", "Detailed", "Strategic"],
    color: "from-green-400 to-teal-500",
    bgColor: "bg-green-50",
    icon: Map,
  },
}

export default function OnboardingPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<string[]>([])
  const [showResult, setShowResult] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleAnswer = (archetype: string) => {
    const newAnswers = [...answers, archetype]
    setAnswers(newAnswers)

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setIsLoading(true)

      // Calculate result
      setTimeout(() => {
        const counts = newAnswers.reduce(
          (acc, arch) => {
            acc[arch] = (acc[arch] || 0) + 1
            return acc
          },
          {} as Record<string, number>,
        )

        const result = Object.entries(counts).reduce((a, b) => (counts[a[0]] > counts[b[0]] ? a : b))[0]

        localStorage.setItem("saalsa-archetype", result)
        setIsLoading(false)
        setShowResult(true)
      }, 2000)
    }
  }

  const getResult = () => {
    const counts = answers.reduce(
      (acc, arch) => {
        acc[arch] = (acc[arch] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    )

    return Object.entries(counts).reduce((a, b) => (counts[a[0]] > counts[b[0]] ? a : b))[0]
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-rose-50 via-amber-50 to-orange-50 relative overflow-hidden flex items-center justify-center">
        <AnimatedBackground />
        <Card className="relative z-10 max-w-md w-full p-8 bg-white/20 backdrop-blur-md border-rose-200/50 shadow-2xl text-center">
          <div className="animate-spin-slow mb-6">
            <Compass className="w-16 h-16 text-rose-500 mx-auto" />
          </div>
          <h2 className="text-2xl font-serif text-rose-800 mb-4">Discovering your travel soul...</h2>
          <p className="text-rose-600">We're analyzing your responses to reveal your unique travel personality.</p>
          <div className="mt-6">
            <div className="w-full bg-rose-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-rose-500 to-orange-500 h-2 rounded-full animate-pulse"
                style={{ width: "75%" }}
              ></div>
            </div>
          </div>
        </Card>
      </div>
    )
  }

  if (showResult) {
    const resultArchetype = getResult()
    const archetype = archetypes[resultArchetype as keyof typeof archetypes]

    return (
      <div
        className={`min-h-screen ${archetype.bgColor} relative overflow-hidden flex items-center justify-center p-6`}
      >
        <AnimatedBackground />
        <Card className="relative z-10 max-w-2xl w-full p-8 bg-white/20 backdrop-blur-md border-0 shadow-2xl">
          <div className="text-center">
            <div className="mb-6 animate-bounce">
              <CharacterAvatar archetype={resultArchetype as any} size="xl" animated={true} className="mx-auto" />
            </div>

            <h1 className="text-3xl font-serif text-gray-800 mb-4">You are...</h1>

            <h2 className="text-4xl font-serif text-gray-900 mb-6">{archetype.title}</h2>

            <p className="text-lg text-gray-700 mb-6 leading-relaxed">{archetype.description}</p>

            <div className="flex flex-wrap justify-center gap-2 mb-8">
              {archetype.traits.map((trait, index) => (
                <Badge
                  key={index}
                  className={`bg-gradient-to-r ${archetype.color} text-white px-3 py-1 animate-fade-in`}
                  style={{ animationDelay: `${index * 0.2}s` }}
                >
                  {trait}
                </Badge>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={() => router.push("/dashboard")}
                className={`bg-gradient-to-r ${archetype.color} text-white px-8 py-3 rounded-full hover:shadow-lg transition-all duration-300 animate-glow-pulse`}
              >
                Enter Your Saalsa World
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>

              <Button
                variant="outline"
                onClick={() => {
                  setCurrentQuestion(0)
                  setAnswers([])
                  setShowResult(false)
                }}
                className="px-8 py-3 rounded-full bg-white/50 backdrop-blur-sm border-white/30"
              >
                Retake Quiz
              </Button>
            </div>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-amber-50 to-orange-50 relative overflow-hidden p-6">
      <AnimatedBackground />

      <div className="relative z-10 max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Link href="/" className="flex items-center text-rose-700 hover:text-rose-800 transition-colors">
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back
          </Link>
          <div className="flex items-center space-x-2">
            <Compass className="w-6 h-6 text-rose-600 animate-spin-slow" />
            <span className="text-xl font-serif text-rose-800">Saalsa</span>
          </div>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-rose-600 mb-2">
            <span>Discovering your travel soul...</span>
            <span>
              {currentQuestion + 1} of {questions.length}
            </span>
          </div>
          <Progress value={progress} className="h-3 bg-rose-200/50" />
        </div>

        {/* Question */}
        <Card className="p-8 bg-white/20 backdrop-blur-md border-rose-200/50 shadow-lg">
          <div className="text-center mb-8">
            <h1 className="text-2xl md:text-3xl font-serif text-rose-800 mb-4">What's Your Travel Soul?</h1>
            <p className="text-lg text-rose-700 leading-relaxed">{questions[currentQuestion].question}</p>
          </div>

          <div className="grid gap-4 max-w-2xl mx-auto">
            {questions[currentQuestion].options.map((option, index) => (
              <Button
                key={index}
                variant="outline"
                className="p-6 h-auto text-left justify-start bg-white/30 hover:bg-white/50 border-rose-200/50 hover:border-rose-300 transition-all duration-300 hover:shadow-md hover:scale-105 backdrop-blur-sm"
                onClick={() => handleAnswer(option.archetype)}
              >
                <span className="mr-3 text-2xl">{option.icon}</span>
                <span className="text-rose-800 leading-relaxed">{option.text}</span>
              </Button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
