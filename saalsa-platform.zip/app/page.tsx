"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { AnimatedBackground } from "@/components/animated-background"
import {
  Heart,
  MapPin,
  BookOpen,
  Compass,
  Star,
  ArrowRight,
  Users,
  Globe,
  Sparkles,
  Mail,
  Phone,
  Instagram,
  Twitter,
  Facebook,
} from "lucide-react"
import Link from "next/link"

const taglines = ["wild-hearted traveler", "soul-seeking wanderer", "story-collecting nomad", "dream-chasing explorer"]

export default function LandingPage() {
  const [currentTagline, setCurrentTagline] = useState(0)
  const [isHovered, setIsHovered] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTagline((prev) => (prev + 1) % taglines.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-rose-50 to-orange-50 relative overflow-hidden">
      <AnimatedBackground />

      {/* Navigation */}
      <nav className="relative z-10 flex justify-between items-center p-6 md:p-8 bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-rose-400 to-orange-400 rounded-full flex items-center justify-center animate-glow-pulse">
            <Compass className="w-4 h-4 text-white" />
          </div>
          <span className="text-2xl font-serif text-rose-800">Saalsa</span>
        </div>
        <div className="flex items-center space-x-6">
          <Link href="/login" className="text-rose-700 hover:text-rose-800 transition-colors">
            Sign In
          </Link>
          <Link href="/onboarding">
            <Button className="bg-rose-500 hover:bg-rose-600 text-white rounded-full px-6 shadow-lg hover:shadow-xl transition-all duration-300">
              Begin Journey
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative z-10 container mx-auto px-6 py-12 md:py-20">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-serif text-rose-800 mb-6 leading-tight">
            For the <span className="text-orange-600 animate-fade-in inline-block">{taglines[currentTagline]}</span>
          </h1>

          <p className="text-xl md:text-2xl text-rose-700 mb-8 font-light leading-relaxed">
            Not just where to go — but how it feels to be there.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Link href="/onboarding">
              <Button
                size="lg"
                className="bg-gradient-to-r from-rose-500 to-orange-500 hover:from-rose-600 hover:to-orange-600 text-white rounded-full px-8 py-4 text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300"
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
              >
                Discover Your Travel Soul
                <ArrowRight
                  className={`ml-2 w-5 h-5 transition-transform duration-300 ${isHovered ? "translate-x-1" : ""}`}
                />
              </Button>
            </Link>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            <Card className="p-6 bg-white/20 backdrop-blur-md border-rose-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 hover:bg-white/30">
              <div className="w-12 h-12 bg-rose-100/80 rounded-full flex items-center justify-center mb-4 mx-auto animate-particle-float">
                <Heart className="w-6 h-6 text-rose-500" />
              </div>
              <h3 className="font-serif text-lg text-rose-800 mb-2">Mood-Aware</h3>
              <p className="text-rose-600 text-sm">Saalsa knows if you feel excited, lost, calm, or overwhelmed</p>
            </Card>

            <Card className="p-6 bg-white/20 backdrop-blur-md border-orange-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 hover:bg-white/30">
              <div
                className="w-12 h-12 bg-orange-100/80 rounded-full flex items-center justify-center mb-4 mx-auto animate-particle-float"
                style={{ animationDelay: "0.5s" }}
              >
                <MapPin className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="font-serif text-lg text-orange-800 mb-2">SoulSpots</h3>
              <p className="text-orange-600 text-sm">Discover places rated by feels, not stars</p>
            </Card>

            <Card className="p-6 bg-white/20 backdrop-blur-md border-amber-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 hover:bg-white/30">
              <div
                className="w-12 h-12 bg-amber-100/80 rounded-full flex items-center justify-center mb-4 mx-auto animate-particle-float"
                style={{ animationDelay: "1s" }}
              >
                <BookOpen className="w-6 h-6 text-amber-600" />
              </div>
              <h3 className="font-serif text-lg text-amber-800 mb-2">Memory Journal</h3>
              <p className="text-amber-700 text-sm">Capture emotions, not just moments</p>
            </Card>

            <Card className="p-6 bg-white/20 backdrop-blur-md border-rose-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 hover:bg-white/30">
              <div
                className="w-12 h-12 bg-rose-100/80 rounded-full flex items-center justify-center mb-4 mx-auto animate-particle-float"
                style={{ animationDelay: "1.5s" }}
              >
                <Star className="w-6 h-6 text-rose-500" />
              </div>
              <h3 className="font-serif text-lg text-rose-800 mb-2">Raiza AI</h3>
              <p className="text-rose-600 text-sm">Your gentle, soulful travel companion</p>
            </Card>
          </div>
        </div>
      </div>

      {/* Why Saalsa Section */}
      <div className="relative z-10 bg-white/10 backdrop-blur-md py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-serif text-rose-800 mb-4">Why Saalsa?</h2>
            <p className="text-xl text-rose-700 max-w-2xl mx-auto">
              Because travel is more than destinations—it's about the feelings, stories, and connections that transform
              us.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-glow-pulse">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-serif text-xl text-rose-800 mb-2">Emotional Intelligence</h3>
              <p className="text-rose-600">Travel recommendations based on your current mood and emotional needs</p>
            </div>

            <div className="text-center">
              <div
                className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-glow-pulse"
                style={{ animationDelay: "0.5s" }}
              >
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-serif text-xl text-rose-800 mb-2">Community Stories</h3>
              <p className="text-rose-600">Real experiences from fellow travelers, not generic reviews</p>
            </div>

            <div className="text-center">
              <div
                className="w-16 h-16 bg-gradient-to-br from-green-400 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-glow-pulse"
                style={{ animationDelay: "1s" }}
              >
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-serif text-xl text-rose-800 mb-2">Personalized Magic</h3>
              <p className="text-rose-600">AI that understands your travel personality and adapts to your journey</p>
            </div>

            <div className="text-center">
              <div
                className="w-16 h-16 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-glow-pulse"
                style={{ animationDelay: "1.5s" }}
              >
                <Globe className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-serif text-xl text-rose-800 mb-2">Mindful Exploration</h3>
              <p className="text-rose-600">Slow travel philosophy that prioritizes depth over distance</p>
            </div>
          </div>
        </div>
      </div>

      {/* About Us Section */}
      <div className="relative z-10 py-16">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-serif text-rose-800 mb-6">About Saalsa</h2>
            <p className="text-lg text-rose-700 mb-8 leading-relaxed">
              Born from the belief that travel should nourish the soul, not just fill the passport. We're building a
              platform where every journey becomes a story, every destination becomes a feeling, and every traveler
              finds their tribe.
            </p>

            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="text-center">
                <div className="text-3xl font-serif text-orange-600 mb-2">10K+</div>
                <div className="text-rose-700">Soul Travelers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-serif text-orange-600 mb-2">50K+</div>
                <div className="text-rose-700">Memories Captured</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-serif text-orange-600 mb-2">150+</div>
                <div className="text-rose-700">Countries Explored</div>
              </div>
            </div>

            <blockquote className="text-2xl md:text-3xl font-serif text-rose-800 italic mb-4">
              "Saalsa is not just an app. It's a movement."
            </blockquote>
            <p className="text-rose-600 text-lg">
              For those who roam not for pictures — but for peace, meaning, and memory.
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 border-t border-rose-200/50 bg-white/10 backdrop-blur-md py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-rose-400 to-orange-400 rounded-full flex items-center justify-center">
                  <Compass className="w-4 h-4 text-white" />
                </div>
                <span className="text-2xl font-serif text-rose-800">Saalsa</span>
              </div>
              <p className="text-rose-600 text-sm mb-4">
                For the wild-hearted traveler seeking meaning in every journey.
              </p>
              <div className="flex space-x-3">
                <Button size="sm" variant="ghost" className="text-rose-600 hover:text-rose-700">
                  <Instagram className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="ghost" className="text-rose-600 hover:text-rose-700">
                  <Twitter className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="ghost" className="text-rose-600 hover:text-rose-700">
                  <Facebook className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Features */}
            <div>
              <h4 className="font-serif text-lg text-rose-800 mb-4">Features</h4>
              <ul className="space-y-2 text-sm text-rose-600">
                <li>
                  <Link href="/onboarding" className="hover:text-rose-700 transition-colors">
                    Travel Soul Quiz
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard" className="hover:text-rose-700 transition-colors">
                    Mood Dashboard
                  </Link>
                </li>
                <li>
                  <Link href="/rozi" className="hover:text-rose-700 transition-colors">
                    Rozi AI Companion
                  </Link>
                </li>
                <li>
                  <Link href="/journal" className="hover:text-rose-700 transition-colors">
                    Memory Journal
                  </Link>
                </li>
                <li>
                  <Link href="/soulspots" className="hover:text-rose-700 transition-colors">
                    SoulSpots Map
                  </Link>
                </li>
                <li>
                  <Link href="/planner" className="hover:text-rose-700 transition-colors">
                    Trip Planner
                  </Link>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="font-serif text-lg text-rose-800 mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-rose-600">
                <li>
                  <Link href="/about" className="hover:text-rose-700 transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-rose-700 transition-colors">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="/press" className="hover:text-rose-700 transition-colors">
                    Press
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="hover:text-rose-700 transition-colors">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-rose-700 transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-rose-700 transition-colors">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-serif text-lg text-rose-800 mb-4">Get in Touch</h4>
              <div className="space-y-3 text-sm text-rose-600">
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4" />
                  <span>hello@saalsa.com</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="mt-4">
                  <Link href="/onboarding">
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-rose-500 to-orange-500 hover:from-rose-600 hover:to-orange-600 text-white rounded-full"
                    >
                      Start Your Journey
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-rose-200/50 pt-8 text-center">
            <p className="text-rose-600 text-sm">Made with Love by Aseeverse</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
