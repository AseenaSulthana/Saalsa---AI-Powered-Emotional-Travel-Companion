"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Compass, Heart, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function LoginPage() {
  const [isSignUp, setIsSignUp] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-amber-50 to-orange-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Back to Home */}
        <Link href="/" className="flex items-center text-rose-700 hover:text-rose-800 transition-colors mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        <Card className="p-8 bg-white/80 backdrop-blur-sm border-rose-200 shadow-2xl">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-rose-400 to-orange-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <Compass className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-serif text-rose-800 mb-2">Welcome to Saalsa</h1>
            <p className="text-rose-600">{isSignUp ? "Begin your journey of discovery" : "Welcome back, wild heart"}</p>
          </div>

          {/* Form */}
          <form className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-rose-700 mb-2">Email</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="bg-white/50 border-rose-200 focus:border-rose-400"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-rose-700 mb-2">Password</label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="bg-white/50 border-rose-200 focus:border-rose-400"
              />
            </div>

            {isSignUp && (
              <div>
                <label className="block text-sm font-medium text-rose-700 mb-2">Confirm Password</label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  className="bg-white/50 border-rose-200 focus:border-rose-400"
                />
              </div>
            )}

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-rose-500 to-orange-500 hover:from-rose-600 hover:to-orange-600 text-white py-3 rounded-full font-medium"
            >
              {isSignUp ? "Begin Your Journey" : "Welcome Back"}
              <Heart className="w-4 h-4 ml-2" />
            </Button>
          </form>

          {/* Toggle */}
          <div className="text-center mt-6">
            <p className="text-rose-600">
              {isSignUp ? "Already have an account?" : "Don't have an account?"}
              <button
                onClick={() => setIsSignUp(!isSignUp)}
                className="ml-2 text-rose-700 hover:text-rose-800 font-medium underline"
              >
                {isSignUp ? "Sign In" : "Sign Up"}
              </button>
            </p>
          </div>

          {/* Social Login */}
          <div className="mt-6 pt-6 border-t border-rose-200">
            <p className="text-center text-sm text-rose-600 mb-4">Or continue with</p>
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="bg-white/50 border-rose-200">
                Google
              </Button>
              <Button variant="outline" className="bg-white/50 border-rose-200">
                Apple
              </Button>
            </div>
          </div>
        </Card>

        {/* Quote */}
        <div className="text-center mt-8">
          <blockquote className="text-rose-700 italic">"Not all those who wander are lost"</blockquote>
        </div>
      </div>
    </div>
  )
}
