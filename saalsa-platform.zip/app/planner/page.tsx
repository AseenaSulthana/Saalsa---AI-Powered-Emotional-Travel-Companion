"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { AnimatedBackground } from "@/components/animated-background"
import {
  ArrowLeft,
  Plus,
  Calendar,
  MapPin,
  Clock,
  Coffee,
  Camera,
  Book,
  Heart,
  Sunset,
  TreePine,
  X,
} from "lucide-react"
import Link from "next/link"

const soulBlocks = [
  { icon: Coffee, label: "Café to breathe", color: "bg-amber-100 text-amber-800" },
  { icon: Book, label: "Hidden bookstore", color: "bg-blue-100 text-blue-800" },
  { icon: Camera, label: "Photo moment", color: "bg-purple-100 text-purple-800" },
  { icon: Heart, label: "People watching", color: "bg-rose-100 text-rose-800" },
  { icon: Sunset, label: "Sunset spot", color: "bg-orange-100 text-orange-800" },
  { icon: TreePine, label: "Nature escape", color: "bg-green-100 text-green-800" },
]

interface SoulMoment {
  time: string
  type: string
  title: string
  location: string
  notes: string
}

interface TripDay {
  date: string
  blocks: SoulMoment[]
}

interface Trip {
  title: string
  destination: string
  dates: string
  startDate: string
  endDate: string
  days: TripDay[]
}

export default function PlannerPage() {
  const [isCreating, setIsCreating] = useState(false)
  const [isAddingMoment, setIsAddingMoment] = useState(false)
  const [selectedDayIndex, setSelectedDayIndex] = useState(0)
  const [newTrip, setNewTrip] = useState({ title: "", destination: "", startDate: "", endDate: "" })
  const [newMoment, setNewMoment] = useState({
    time: "",
    type: "",
    title: "",
    location: "",
    notes: "",
  })

  const [trips, setTrips] = useState<Trip[]>([
    {
      title: "Weekend in Kyoto",
      destination: "Kyoto, Japan",
      dates: "March 15-17, 2024",
      startDate: "2024-03-15",
      endDate: "2024-03-17",
      days: [
        {
          date: "March 15",
          blocks: [
            {
              time: "09:00",
              type: "Café to breathe",
              title: "Morning coffee at Kurasu",
              location: "Kyoto Station",
              notes: "Start slow, let the city wake up with you",
            },
            {
              time: "11:00",
              type: "Hidden bookstore",
              title: "Tsuki to Suppon",
              location: "Nishiki Market",
              notes: "Look for poetry books in English",
            },
            {
              time: "14:00",
              type: "People watching",
              title: "Philosopher's Path",
              location: "Higashiyama",
              notes: "Bring your journal",
            },
            {
              time: "17:30",
              type: "Sunset spot",
              title: "Kiyomizu-dera Temple",
              location: "Eastern Kyoto",
              notes: "Golden hour magic",
            },
          ],
        },
      ],
    },
  ])

  const [currentTripIndex, setCurrentTripIndex] = useState(0)
  const currentTrip = trips[currentTripIndex]

  const createNewTrip = () => {
    if (!newTrip.title || !newTrip.destination || !newTrip.startDate || !newTrip.endDate) {
      alert("Please fill in all fields")
      return
    }

    const start = new Date(newTrip.startDate)
    const end = new Date(newTrip.endDate)
    const days: TripDay[] = []

    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      days.push({
        date: d.toLocaleDateString("en-US", { month: "long", day: "numeric" }),
        blocks: [],
      })
    }

    const trip: Trip = {
      ...newTrip,
      dates: `${start.toLocaleDateString("en-US", { month: "long", day: "numeric" })} - ${end.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}`,
      days,
    }

    setTrips([...trips, trip])
    setCurrentTripIndex(trips.length)
    setIsCreating(false)
    setNewTrip({ title: "", destination: "", startDate: "", endDate: "" })
  }

  const addSoulMoment = () => {
    if (!newMoment.time || !newMoment.type || !newMoment.title || !newMoment.location) {
      alert("Please fill in all required fields")
      return
    }

    const updatedTrips = [...trips]
    updatedTrips[currentTripIndex].days[selectedDayIndex].blocks.push({ ...newMoment })
    updatedTrips[currentTripIndex].days[selectedDayIndex].blocks.sort((a, b) => a.time.localeCompare(b.time))

    setTrips(updatedTrips)
    setIsAddingMoment(false)
    setNewMoment({ time: "", type: "", title: "", location: "", notes: "" })
  }

  const deleteSoulMoment = (dayIndex: number, blockIndex: number) => {
    const updatedTrips = [...trips]
    updatedTrips[currentTripIndex].days[dayIndex].blocks.splice(blockIndex, 1)
    setTrips(updatedTrips)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 relative overflow-hidden">
      <AnimatedBackground />

      {/* Header */}
      <div className="relative z-10 bg-white/10 backdrop-blur-md border-b border-teal-200/50 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center text-teal-700 hover:text-teal-800 transition-colors">
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </Link>
          <div className="flex items-center space-x-3">
            <Calendar className="w-6 h-6 text-teal-600" />
            <h1 className="font-serif text-2xl text-teal-800">Plan & Flow</h1>
            <Button
              onClick={() => setIsCreating(true)}
              className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Journey
            </Button>
          </div>
        </div>
      </div>

      <div className="relative z-10 container mx-auto p-6 max-w-6xl">
        {isCreating ? (
          /* Create New Trip */
          <Card className="p-8 bg-white/20 backdrop-blur-md border-teal-200/50 shadow-lg">
            <h2 className="font-serif text-2xl text-teal-800 mb-6">Plan Your Soul Journey</h2>

            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-teal-700 mb-2">
                    What shall we call this adventure?
                  </label>
                  <Input
                    value={newTrip.title}
                    onChange={(e) => setNewTrip((prev) => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., Soul-searching in Bali"
                    className="bg-white/50 border-teal-200 backdrop-blur-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-teal-700 mb-2">
                    Where is your heart calling you?
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 w-4 h-4 text-teal-500" />
                    <Input
                      value={newTrip.destination}
                      onChange={(e) => setNewTrip((prev) => ({ ...prev, destination: e.target.value }))}
                      placeholder="Destination"
                      className="pl-10 bg-white/50 border-teal-200 backdrop-blur-sm"
                    />
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-teal-700 mb-2">Journey begins</label>
                  <Input
                    type="date"
                    value={newTrip.startDate}
                    onChange={(e) => setNewTrip((prev) => ({ ...prev, startDate: e.target.value }))}
                    className="bg-white/50 border-teal-200 backdrop-blur-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-teal-700 mb-2">Journey ends</label>
                  <Input
                    type="date"
                    value={newTrip.endDate}
                    onChange={(e) => setNewTrip((prev) => ({ ...prev, endDate: e.target.value }))}
                    className="bg-white/50 border-teal-200 backdrop-blur-sm"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <Button
                  variant="outline"
                  onClick={() => setIsCreating(false)}
                  className="bg-white/50 border-teal-200 backdrop-blur-sm"
                >
                  Cancel
                </Button>
                <Button
                  onClick={createNewTrip}
                  className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Create Journey
                </Button>
              </div>
            </div>
          </Card>
        ) : (
          /* Trip Timeline */
          <div>
            {/* Trip Selector */}
            {trips.length > 1 && (
              <div className="mb-6 flex gap-3 overflow-x-auto pb-2">
                {trips.map((trip, index) => (
                  <Button
                    key={index}
                    variant={currentTripIndex === index ? "default" : "outline"}
                    onClick={() => setCurrentTripIndex(index)}
                    className={`${currentTripIndex === index ? "bg-teal-500 text-white" : "bg-white/30 backdrop-blur-sm"} rounded-full whitespace-nowrap`}
                  >
                    {trip.title}
                  </Button>
                ))}
              </div>
            )}

            {/* Trip Header */}
            <Card className="p-6 bg-white/20 backdrop-blur-md border-teal-200/50 mb-6 shadow-lg">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="font-serif text-2xl text-teal-800 mb-2">{currentTrip.title}</h2>
                  <div className="flex items-center text-teal-600 mb-4">
                    <Calendar className="w-4 h-4 mr-2" />
                    {currentTrip.dates}
                  </div>
                  <p className="text-teal-700">
                    Organize your trip not like to-do lists, but like moodboards. Each moment is a soul block waiting to
                    be experienced.
                  </p>
                </div>
                <Badge className="bg-teal-100/80 text-teal-800 border-teal-200">{currentTrip.days.length} days</Badge>
              </div>
            </Card>

            {/* Soul Blocks Palette */}
            <Card className="p-6 bg-white/20 backdrop-blur-md border-teal-200/50 mb-6 shadow-lg">
              <h3 className="font-serif text-lg text-teal-800 mb-4">Soul Blocks</h3>
              <p className="text-sm text-teal-600 mb-4">Choose a moment type and add it to your timeline</p>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                {soulBlocks.map((block, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className={`h-auto p-4 flex flex-col items-center space-y-2 ${block.color} border-teal-200 hover:shadow-md transition-all duration-300 backdrop-blur-sm`}
                  >
                    <block.icon className="w-6 h-6" />
                    <span className="text-xs text-center">{block.label}</span>
                  </Button>
                ))}
              </div>
            </Card>

            {/* Timeline */}
            <div className="space-y-6">
              {currentTrip.days.map((day, dayIndex) => (
                <Card key={dayIndex} className="p-6 bg-white/20 backdrop-blur-md border-teal-200/50 shadow-lg">
                  <h3 className="font-serif text-xl text-teal-800 mb-4">{day.date}</h3>

                  <div className="space-y-4">
                    {day.blocks.map((block, blockIndex) => (
                      <div
                        key={blockIndex}
                        className="flex items-start space-x-4 p-4 bg-white/30 rounded-lg border border-teal-100 backdrop-blur-sm group"
                      >
                        <div className="flex items-center justify-center w-12 h-12 bg-teal-100/80 rounded-full flex-shrink-0">
                          <Clock className="w-5 h-5 text-teal-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <span className="text-sm font-medium text-teal-600">{block.time}</span>
                            <Badge variant="secondary" className="bg-teal-100/80 text-teal-700 border-teal-200">
                              {block.type}
                            </Badge>
                          </div>
                          <h4 className="font-medium text-teal-800 mb-1">{block.title}</h4>
                          <div className="flex items-center text-sm text-teal-600 mb-2">
                            <MapPin className="w-3 h-3 mr-1" />
                            {block.location}
                          </div>
                          {block.notes && <p className="text-sm text-teal-700 italic">{block.notes}</p>}
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-red-600 hover:text-red-700 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => deleteSoulMoment(dayIndex, blockIndex)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}

                    {/* Add Block Button */}
                    <Button
                      variant="outline"
                      className="w-full border-2 border-dashed border-teal-300 bg-white/20 hover:bg-white/40 text-teal-600 backdrop-blur-sm transition-all duration-300"
                      onClick={() => {
                        setSelectedDayIndex(dayIndex)
                        setIsAddingMoment(true)
                      }}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add a soul moment
                    </Button>
                  </div>
                </Card>
              ))}
            </div>

            {/* Packing Suggestions */}
            <Card className="mt-6 p-6 bg-gradient-to-r from-teal-100/80 to-cyan-100/80 border-teal-200/50 backdrop-blur-md shadow-lg">
              <h3 className="font-serif text-lg text-teal-800 mb-4">Soulful Packing Suggestions</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-teal-700 mb-2">For your heart:</h4>
                  <ul className="text-sm text-teal-600 space-y-1">
                    <li>• A book that calms you 🧘‍♀️</li>
                    <li>• Your favorite pen for journaling ✍️</li>
                    <li>• Something that smells like home 🏠</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-teal-700 mb-2">For the weather & mood:</h4>
                  <ul className="text-sm text-teal-600 space-y-1">
                    <li>• Light layers for temple visits 🏛️</li>
                    <li>• Comfortable shoes for wandering 👟</li>
                    <li>• A small bag for spontaneous finds 🎒</li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Add Soul Moment Modal */}
        {isAddingMoment && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 z-50">
            <Card className="max-w-2xl w-full p-8 bg-white/90 backdrop-blur-md border-teal-200 shadow-2xl">
              <h2 className="font-serif text-2xl text-teal-800 mb-6">Add a Soul Moment</h2>

              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-teal-700 mb-2">Time</label>
                    <Input
                      type="time"
                      value={newMoment.time}
                      onChange={(e) => setNewMoment((prev) => ({ ...prev, time: e.target.value }))}
                      className="bg-white border-teal-200"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-teal-700 mb-2">Moment Type</label>
                    <select
                      value={newMoment.type}
                      onChange={(e) => setNewMoment((prev) => ({ ...prev, type: e.target.value }))}
                      className="w-full p-2 rounded-md border border-teal-200 bg-white"
                    >
                      <option value="">Select type...</option>
                      {soulBlocks.map((block) => (
                        <option key={block.label} value={block.label}>
                          {block.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-teal-700 mb-2">Title</label>
                  <Input
                    value={newMoment.title}
                    onChange={(e) => setNewMoment((prev) => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., Morning coffee at local café"
                    className="bg-white border-teal-200"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-teal-700 mb-2">Location</label>
                  <Input
                    value={newMoment.location}
                    onChange={(e) => setNewMoment((prev) => ({ ...prev, location: e.target.value }))}
                    placeholder="e.g., Downtown"
                    className="bg-white border-teal-200"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-teal-700 mb-2">Notes (optional)</label>
                  <Input
                    value={newMoment.notes}
                    onChange={(e) => setNewMoment((prev) => ({ ...prev, notes: e.target.value }))}
                    placeholder="e.g., Don't forget your journal"
                    className="bg-white border-teal-200"
                  />
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsAddingMoment(false)
                      setNewMoment({ time: "", type: "", title: "", location: "", notes: "" })
                    }}
                    className="bg-white/50 border-teal-200"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={addSoulMoment}
                    className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    Add Moment
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
