"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { AnimatedBackground } from "@/components/animated-background"
import { ArrowLeft, Plus, Camera, Mic, MapPin, Heart, Download, X, ImageIcon } from "lucide-react"
import Link from "next/link"

const emotionTags = [
  { emoji: "☀️", label: "Joyful", color: "bg-yellow-100/80 text-yellow-800" },
  { emoji: "🌧️", label: "Melancholy", color: "bg-blue-100/80 text-blue-800" },
  { emoji: "🍂", label: "Nostalgic", color: "bg-orange-100/80 text-orange-800" },
  { emoji: "✨", label: "Magical", color: "bg-purple-100/80 text-purple-800" },
  { emoji: "🌿", label: "Peaceful", color: "bg-green-100/80 text-green-800" },
  { emoji: "🔥", label: "Passionate", color: "bg-red-100/80 text-red-800" },
  { emoji: "🌙", label: "Dreamy", color: "bg-indigo-100/80 text-indigo-800" },
  { emoji: "💫", label: "Inspired", color: "bg-pink-100/80 text-pink-800" },
]

interface JournalEntry {
  id: number
  title: string
  location: string
  date: string
  emotions: string[]
  preview: string
  content: string
  image: string | null
}

export default function JournalPage() {
  const [isCreating, setIsCreating] = useState(false)
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [newEntry, setNewEntry] = useState({
    title: "",
    location: "",
    content: "",
    emotions: [] as string[],
  })

  const [entries, setEntries] = useState<JournalEntry[]>([
    {
      id: 1,
      title: "Sunset at Santorini",
      location: "Oia, Greece",
      date: "2024-01-15",
      emotions: ["☀️", "💫"],
      preview:
        "The way the light painted everything golden... I've never felt so small yet so connected to something infinite.",
      content:
        "The way the light painted everything golden... I've never felt so small yet so connected to something infinite. Standing on the cliff edge, watching the sun melt into the Aegean Sea, I understood why people chase moments like these.",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      title: "Hidden café discovery",
      location: "Montmartre, Paris",
      date: "2024-01-10",
      emotions: ["🌿", "🍂"],
      preview:
        "Found this tiny café where the owner remembered my name after just one visit. Sometimes magic is in the smallest gestures.",
      content:
        "Found this tiny café where the owner remembered my name after just one visit. The walls were lined with vintage books, and the coffee tasted like home. Sometimes magic is in the smallest gestures.",
      image: "/placeholder.svg?height=200&width=300",
    },
  ])

  const toggleEmotion = (emotion: string) => {
    setNewEntry((prev) => ({
      ...prev,
      emotions: prev.emotions.includes(emotion)
        ? prev.emotions.filter((e) => e !== emotion)
        : [...prev.emotions, emotion],
    }))
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setSelectedImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const saveEntry = () => {
    if (!newEntry.title || !newEntry.location || !newEntry.content) {
      alert("Please fill in all required fields")
      return
    }

    const entry: JournalEntry = {
      id: entries.length + 1,
      title: newEntry.title,
      location: newEntry.location,
      date: new Date().toISOString().split("T")[0],
      emotions: newEntry.emotions,
      preview: newEntry.content.slice(0, 100) + "...",
      content: newEntry.content,
      image: selectedImage,
    }

    setEntries([entry, ...entries])
    setIsCreating(false)
    setNewEntry({ title: "", location: "", content: "", emotions: [] })
    setSelectedImage(null)
  }

  const deleteEntry = (id: number) => {
    if (confirm("Are you sure you want to delete this memory?")) {
      setEntries(entries.filter((entry) => entry.id !== id))
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-rose-50 relative overflow-hidden">
      <AnimatedBackground />

      {/* Header */}
      <div className="relative z-10 bg-white/10 backdrop-blur-md border-b border-orange-200/50 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center text-orange-700 hover:text-orange-800 transition-colors">
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </Link>
          <div className="flex items-center space-x-3">
            <h1 className="font-serif text-2xl text-orange-800">Saalsa Journal</h1>
            <Button
              onClick={() => setIsCreating(true)}
              className="bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Entry
            </Button>
          </div>
        </div>
      </div>

      <div className="relative z-10 container mx-auto p-6 max-w-6xl">
        {isCreating ? (
          /* Create New Entry */
          <Card className="p-8 bg-white/20 backdrop-blur-md border-orange-200/50 shadow-lg">
            <h2 className="font-serif text-2xl text-orange-800 mb-6">Capture This Moment</h2>

            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-orange-700 mb-2">
                    What would you call this moment?
                  </label>
                  <Input
                    value={newEntry.title}
                    onChange={(e) => setNewEntry((prev) => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., Sunset at the hidden beach"
                    className="bg-white/50 border-orange-200 backdrop-blur-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-orange-700 mb-2">Where did this happen?</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 w-4 h-4 text-orange-500" />
                    <Input
                      value={newEntry.location}
                      onChange={(e) => setNewEntry((prev) => ({ ...prev, location: e.target.value }))}
                      placeholder="Location"
                      className="pl-10 bg-white/50 border-orange-200 backdrop-blur-sm"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-orange-700 mb-2">How did it feel?</label>
                <div className="flex flex-wrap gap-2 mb-4">
                  {emotionTags.map((emotion, index) => (
                    <Button
                      key={index}
                      variant={newEntry.emotions.includes(emotion.emoji) ? "default" : "outline"}
                      size="sm"
                      className={`${newEntry.emotions.includes(emotion.emoji) ? emotion.color : "bg-white/30 border-orange-200/50"} backdrop-blur-sm transition-all duration-300`}
                      onClick={() => toggleEmotion(emotion.emoji)}
                    >
                      <span className="mr-1">{emotion.emoji}</span>
                      {emotion.label}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-orange-700 mb-2">Tell your story...</label>
                <Textarea
                  value={newEntry.content}
                  onChange={(e) => setNewEntry((prev) => ({ ...prev, content: e.target.value }))}
                  placeholder="Let your heart speak. What made this moment special? How did it change you?"
                  rows={6}
                  className="bg-white/50 border-orange-200 resize-none backdrop-blur-sm"
                />
              </div>

              <div className="flex items-center space-x-4">
                <label className="cursor-pointer">
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                  <Button variant="outline" className="bg-white/50 border-orange-200 backdrop-blur-sm" type="button">
                    <Camera className="w-4 h-4 mr-2" />
                    Add Photo
                  </Button>
                </label>
                <Button variant="outline" className="bg-white/50 border-orange-200 backdrop-blur-sm" disabled>
                  <Mic className="w-4 h-4 mr-2" />
                  Voice Note
                </Button>
              </div>

              {selectedImage && (
                <div className="relative">
                  <img
                    src={selectedImage || "/placeholder.svg"}
                    alt="Preview"
                    className="w-full h-64 object-cover rounded-lg border-2 border-orange-200"
                  />
                  <Button
                    size="sm"
                    variant="destructive"
                    className="absolute top-2 right-2"
                    onClick={() => setSelectedImage(null)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              )}

              <div className="flex justify-end space-x-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsCreating(false)
                    setNewEntry({ title: "", location: "", content: "", emotions: [] })
                    setSelectedImage(null)
                  }}
                  className="bg-white/50 border-orange-200 backdrop-blur-sm"
                >
                  Cancel
                </Button>
                <Button
                  onClick={saveEntry}
                  className="bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  <Heart className="w-4 h-4 mr-2" />
                  Save Memory
                </Button>
              </div>
            </div>
          </Card>
        ) : (
          /* Journal Entries */
          <div>
            {/* Stats */}
            <div className="grid md:grid-cols-4 gap-4 mb-8">
              <Card className="p-4 bg-white/20 backdrop-blur-md border-orange-200/50 text-center shadow-lg">
                <div className="text-2xl font-serif text-orange-800">{entries.length}</div>
                <div className="text-sm text-orange-600">Memories Captured</div>
              </Card>
              <Card className="p-4 bg-white/20 backdrop-blur-md border-rose-200/50 text-center shadow-lg">
                <div className="text-2xl font-serif text-rose-800">
                  {new Set(entries.map((e) => e.location.split(",").pop()?.trim())).size}
                </div>
                <div className="text-sm text-rose-600">Places Explored</div>
              </Card>
              <Card className="p-4 bg-white/20 backdrop-blur-md border-amber-200/50 text-center shadow-lg">
                <div className="text-2xl font-serif text-amber-800">
                  {entries.flatMap((e) => e.emotions)[0] || "✨"}
                </div>
                <div className="text-sm text-amber-700">Most Felt Emotion</div>
              </Card>
              <Card className="p-4 bg-white/20 backdrop-blur-md border-orange-200/50 text-center shadow-lg">
                <Button
                  size="sm"
                  variant="outline"
                  className="bg-white/50 border-orange-200 backdrop-blur-sm hover:bg-white/70"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export PDF
                </Button>
              </Card>
            </div>

            {/* Entries Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {entries.map((entry) => (
                <Card
                  key={entry.id}
                  className="overflow-hidden bg-white/20 backdrop-blur-md border-orange-200/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group"
                >
                  <div className="aspect-video bg-gradient-to-br from-orange-200 to-rose-200 relative">
                    {entry.image ? (
                      <img
                        src={entry.image || "/placeholder.svg"}
                        alt={entry.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ImageIcon className="w-12 h-12 text-orange-300" />
                      </div>
                    )}
                    <div className="absolute top-3 right-3 flex space-x-1">
                      {entry.emotions.map((emotion, index) => (
                        <span
                          key={index}
                          className="text-lg bg-white/80 rounded-full w-8 h-8 flex items-center justify-center backdrop-blur-sm"
                        >
                          {emotion}
                        </span>
                      ))}
                    </div>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="absolute top-3 left-3 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => deleteEntry(entry.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="p-4">
                    <h3 className="font-serif text-lg text-orange-800 mb-2">{entry.title}</h3>
                    <div className="flex items-center text-sm text-orange-600 mb-2">
                      <MapPin className="w-3 h-3 mr-1" />
                      {entry.location}
                    </div>
                    <p className="text-sm text-orange-700 mb-3 line-clamp-2">{entry.preview}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-orange-500">{entry.date}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-orange-600 hover:text-orange-700"
                        onClick={() => alert(entry.content)}
                      >
                        Read More
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}

              {/* Add New Entry Card */}
              <Card
                className="border-2 border-dashed border-orange-300 bg-white/10 hover:bg-white/20 transition-all duration-300 cursor-pointer flex items-center justify-center min-h-[300px] backdrop-blur-sm"
                onClick={() => setIsCreating(true)}
              >
                <div className="text-center">
                  <Plus className="w-12 h-12 text-orange-400 mx-auto mb-3" />
                  <p className="text-orange-600 font-medium">Capture a new memory</p>
                  <p className="text-sm text-orange-500">Every moment has a story</p>
                </div>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
